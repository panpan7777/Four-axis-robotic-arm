#ifndef __OLED_H__
#define __OLED_H__
#include "main.h"


//#define OLED_SCL_Clr() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_RESET)//SCL
//#define OLED_SCL_Set() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET)

//#define OLED_SDA_Clr() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,GPIO_PIN_RESET)//SDA
//#define OLED_SDA_Set() HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,GPIO_PIN_SET)

//void OLED_W_SCL(uint8_t Data);
//void OLED_W_SDA(uint8_t Data);


void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowCN(uint8_t Line, uint8_t Column, uint8_t Num);
#endif
